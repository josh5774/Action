const jwt = require('jsonwebtoken');

/**
 * Require a valid JWT. Attaches { id, email, user_type } to req.user.
 */
const authenticate = (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Missing or malformed Authorization header.' });
  }
  const token = authHeader.split(' ')[1];
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.user = payload;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired token.' });
  }
};

/**
 * Require the user to be an approved creative.
 * Must be used after `authenticate`.
 */
const requireCreative = (req, res, next) => {
  if (req.user.user_type !== 'creative' && req.user.user_type !== 'admin') {
    return res.status(403).json({ error: 'Creative account required.' });
  }
  next();
};

/**
 * Require admin privileges.
 * Must be used after `authenticate`.
 */
const requireAdmin = (req, res, next) => {
  if (req.user.user_type !== 'admin') {
    return res.status(403).json({ error: 'Admin privileges required.' });
  }
  next();
};

module.exports = { authenticate, requireCreative, requireAdmin };
