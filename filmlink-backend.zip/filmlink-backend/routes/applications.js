const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const { validate } = require('../middleware/validate');
const { authenticate } = require('../middleware/auth');
const { query } = require('../config/db');

/**
 * POST /api/applications
 * A fan submits a creator application for admin review.
 */
router.post('/',
  authenticate,
  body('profession').notEmpty(),
  body('bio').isLength({ min: 50 }).withMessage('Bio must be at least 50 characters.'),
  validate,
  async (req, res, next) => {
    try {
      const { profession, bio, headshot_url, reel_url, resume_url } = req.body;

      // Prevent duplicate pending applications
      const existing = await query(
        `SELECT id FROM creator_applications WHERE user_id = $1 AND status = 'pending'`,
        [req.user.id]
      );
      if (existing.rows.length) {
        return res.status(409).json({ error: 'You already have a pending application.' });
      }

      const { rows: [application] } = await query(
        `INSERT INTO creator_applications (user_id, profession, bio, headshot_url, reel_url, resume_url)
         VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
        [req.user.id, profession, bio, headshot_url, reel_url, resume_url]
      );
      res.status(201).json({ application });
    } catch (err) {
      next(err);
    }
  }
);

/**
 * GET /api/applications/me
 * User checks the status of their own application.
 */
router.get('/me', authenticate, async (req, res, next) => {
  try {
    const { rows } = await query(
      `SELECT * FROM creator_applications WHERE user_id = $1 ORDER BY created_at DESC LIMIT 1`,
      [req.user.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'No application found.' });
    res.json({ application: rows[0] });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
