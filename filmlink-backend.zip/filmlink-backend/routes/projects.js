const express = require('express');
const router = express.Router();
const { authenticate, requireCreative } = require('../middleware/auth');
const { listProjects, getProject, createProject, applyToRole } = require('../controllers/projectsController');

router.get('/', listProjects);
router.get('/:id', getProject);
router.post('/', authenticate, requireCreative, createProject);
router.post('/roles/:roleId/apply', authenticate, requireCreative, applyToRole);

module.exports = router;
