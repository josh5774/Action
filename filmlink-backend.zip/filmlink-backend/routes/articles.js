const express = require('express');
const router = express.Router();
const { listArticles, getArticle } = require('../controllers/articlesController');

router.get('/', listArticles);
router.get('/:slug', getArticle);

module.exports = router;
