const express = require('express');
const router = express.Router();
const { authenticate, requireCreative } = require('../middleware/auth');
const { getProfile, upsertProfile, followUser, unfollowUser } = require('../controllers/usersController');

router.get('/:id/profile', getProfile);
router.put('/me/profile', authenticate, requireCreative, upsertProfile);
router.post('/:id/follow', authenticate, followUser);
router.delete('/:id/follow', authenticate, unfollowUser);

module.exports = router;
