const express = require('express');
const router = express.Router();
const { authenticate } = require('../middleware/auth');
const { query } = require('../config/db');

/** GET /api/classes */
router.get('/', async (req, res, next) => {
  try {
    const { rows } = await query(
      `SELECT ac.*,
         ROUND(AVG(cr.rating), 1) AS avg_rating,
         COUNT(cr.id)::int        AS review_count
       FROM acting_classes ac
       LEFT JOIN class_reviews cr ON cr.class_id = ac.id
       WHERE ac.is_active = true
       GROUP BY ac.id
       ORDER BY avg_rating DESC NULLS LAST`
    );
    res.json({ classes: rows });
  } catch (err) { next(err); }
});

/** GET /api/classes/:id */
router.get('/:id', async (req, res, next) => {
  try {
    const { rows: [cls] } = await query('SELECT * FROM acting_classes WHERE id = $1', [req.params.id]);
    if (!cls) return res.status(404).json({ error: 'Class not found.' });

    const { rows: reviews } = await query(
      `SELECT cr.*, cp.display_name AS reviewer_name
       FROM class_reviews cr
       LEFT JOIN creative_profiles cp ON cp.user_id = cr.reviewer_id
       WHERE cr.class_id = $1
       ORDER BY cr.created_at DESC`,
      [req.params.id]
    );
    res.json({ class: cls, reviews });
  } catch (err) { next(err); }
});

/** POST /api/classes/:id/reviews  (authenticated) */
router.post('/:id/reviews', authenticate, async (req, res, next) => {
  try {
    const { rating, review_text } = req.body;
    if (!rating || rating < 1 || rating > 5) {
      return res.status(422).json({ error: 'Rating must be between 1 and 5.' });
    }
    const { rows: [review] } = await query(
      `INSERT INTO class_reviews (class_id, reviewer_id, rating, review_text)
       VALUES ($1,$2,$3,$4)
       ON CONFLICT (class_id, reviewer_id) DO UPDATE SET rating = $3, review_text = $4
       RETURNING *`,
      [req.params.id, req.user.id, rating, review_text]
    );
    res.status(201).json({ review });
  } catch (err) { next(err); }
});

module.exports = router;
