const express = require('express');
const router = express.Router();
const { authenticate } = require('../middleware/auth');
const { listEvents, getEvent, rsvp } = require('../controllers/eventsController');

router.get('/', listEvents);
router.get('/:id', getEvent);
router.post('/:id/rsvp', authenticate, rsvp);

module.exports = router;
