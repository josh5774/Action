const express = require('express');
const router = express.Router();
const { authenticate, requireAdmin } = require('../middleware/auth');
const { listApplications, reviewApplication, deactivateUser } = require('../controllers/adminController');

// All admin routes require authentication + admin role
router.use(authenticate, requireAdmin);

router.get('/applications', listApplications);
router.patch('/applications/:id', reviewApplication);
router.patch('/users/:id/deactivate', deactivateUser);

module.exports = router;
