const { query } = require('../config/db');

/** GET /api/articles?category= */
const listArticles = async (req, res, next) => {
  try {
    const { category, page = 1, limit = 20 } = req.query;
    const params = [limit, (page - 1) * limit];
    let categoryClause = '';
    if (category) { categoryClause = 'AND category = $3'; params.push(category); }

    const { rows } = await query(
      `SELECT id, title, slug, cover_url, category, is_sponsored, published_at
       FROM articles
       WHERE is_published = true ${categoryClause}
       ORDER BY published_at DESC
       LIMIT $1 OFFSET $2`,
      params
    );
    res.json({ articles: rows, page: Number(page), limit: Number(limit) });
  } catch (err) { next(err); }
};

/** GET /api/articles/:slug */
const getArticle = async (req, res, next) => {
  try {
    const { rows: [article] } = await query(
      'SELECT * FROM articles WHERE slug = $1 AND is_published = true',
      [req.params.slug]
    );
    if (!article) return res.status(404).json({ error: 'Article not found.' });
    res.json({ article });
  } catch (err) { next(err); }
};

module.exports = { listArticles, getArticle };
