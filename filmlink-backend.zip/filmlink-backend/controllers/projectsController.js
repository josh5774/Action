const { query } = require('../config/db');

/**
 * GET /api/projects
 * Query params: genre, location, compensation, status, page, limit
 */
const listProjects = async (req, res, next) => {
  try {
    const { genre, location, compensation, status = 'open', page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;
    const conditions = ['p.status = $1'];
    const params = [status];
    let i = 2;

    if (genre)    { conditions.push(`p.genre ILIKE $${i++}`);    params.push(`%${genre}%`); }
    if (location) { conditions.push(`p.location ILIKE $${i++}`); params.push(`%${location}%`); }

    const where = conditions.join(' AND ');
    const { rows } = await query(
      `SELECT p.*, cp.display_name AS owner_name, cp.headshot_url AS owner_headshot
       FROM projects p
       LEFT JOIN creative_profiles cp ON cp.user_id = p.owner_id
       WHERE ${where}
       ORDER BY p.is_featured DESC, p.created_at DESC
       LIMIT $${i++} OFFSET $${i}`,
      [...params, limit, offset]
    );
    res.json({ projects: rows, page: Number(page), limit: Number(limit) });
  } catch (err) {
    next(err);
  }
};

/**
 * GET /api/projects/:id
 */
const getProject = async (req, res, next) => {
  try {
    const { rows: [project] } = await query(
      `SELECT p.*, cp.display_name AS owner_name
       FROM projects p
       LEFT JOIN creative_profiles cp ON cp.user_id = p.owner_id
       WHERE p.id = $1`,
      [req.params.id]
    );
    if (!project) return res.status(404).json({ error: 'Project not found.' });

    const { rows: roles } = await query(
      'SELECT * FROM project_roles WHERE project_id = $1 ORDER BY created_at',
      [req.params.id]
    );
    res.json({ project: { ...project, roles } });
  } catch (err) {
    next(err);
  }
};

/**
 * POST /api/projects  (authenticated creative)
 */
const createProject = async (req, res, next) => {
  try {
    const { title, description, genre, project_type, location, shoot_start, shoot_end, roles = [] } = req.body;

    const { rows: [project] } = await query(
      `INSERT INTO projects (owner_id, title, description, genre, project_type, location, shoot_start, shoot_end)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [req.user.id, title, description, genre, project_type, location, shoot_start, shoot_end]
    );

    // Insert roles if provided
    const insertedRoles = [];
    for (const role of roles) {
      const { rows: [r] } = await query(
        `INSERT INTO project_roles (project_id, role_name, role_type, description, compensation, audition_info)
         VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
        [project.id, role.role_name, role.role_type, role.description, role.compensation || 'unpaid', role.audition_info]
      );
      insertedRoles.push(r);
    }

    res.status(201).json({ project: { ...project, roles: insertedRoles } });
  } catch (err) {
    next(err);
  }
};

/**
 * POST /api/projects/roles/:roleId/apply  (authenticated creative)
 */
const applyToRole = async (req, res, next) => {
  try {
    const { cover_note, audition_url } = req.body;
    const { rows: [application] } = await query(
      `INSERT INTO role_applications (role_id, applicant_id, cover_note, audition_url)
       VALUES ($1,$2,$3,$4)
       ON CONFLICT (role_id, applicant_id) DO NOTHING
       RETURNING *`,
      [req.params.roleId, req.user.id, cover_note, audition_url]
    );
    if (!application) return res.status(409).json({ error: 'Already applied to this role.' });
    res.status(201).json({ application });
  } catch (err) {
    next(err);
  }
};

module.exports = { listProjects, getProject, createProject, applyToRole };
