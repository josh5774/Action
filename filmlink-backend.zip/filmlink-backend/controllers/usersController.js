const { query } = require('../config/db');

/**
 * GET /api/users/:id/profile
 */
const getProfile = async (req, res, next) => {
  try {
    const { rows } = await query(
      `SELECT cp.*, u.email, u.user_type
       FROM creative_profiles cp
       JOIN users u ON u.id = cp.user_id
       WHERE cp.user_id = $1`,
      [req.params.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Profile not found.' });
    res.json({ profile: rows[0] });
  } catch (err) {
    next(err);
  }
};

/**
 * PUT /api/users/me/profile  (authenticated creative)
 */
const upsertProfile = async (req, res, next) => {
  try {
    const {
      display_name, profession, bio, location,
      headshot_url, reel_url, resume_url, skills, social_links,
    } = req.body;

    const { rows } = await query(
      `INSERT INTO creative_profiles
         (user_id, display_name, profession, bio, location, headshot_url, reel_url, resume_url, skills, social_links)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
       ON CONFLICT (user_id) DO UPDATE SET
         display_name  = EXCLUDED.display_name,
         profession    = EXCLUDED.profession,
         bio           = EXCLUDED.bio,
         location      = EXCLUDED.location,
         headshot_url  = EXCLUDED.headshot_url,
         reel_url      = EXCLUDED.reel_url,
         resume_url    = EXCLUDED.resume_url,
         skills        = EXCLUDED.skills,
         social_links  = EXCLUDED.social_links,
         updated_at    = NOW()
       RETURNING *`,
      [req.user.id, display_name, profession, bio, location,
       headshot_url, reel_url, resume_url, skills, social_links]
    );
    res.json({ profile: rows[0] });
  } catch (err) {
    next(err);
  }
};

/**
 * POST /api/users/:id/follow  (authenticated)
 */
const followUser = async (req, res, next) => {
  try {
    await query(
      `INSERT INTO follows (follower_id, following_id) VALUES ($1, $2) ON CONFLICT DO NOTHING`,
      [req.user.id, req.params.id]
    );
    res.json({ message: 'Following.' });
  } catch (err) {
    next(err);
  }
};

/**
 * DELETE /api/users/:id/follow  (authenticated)
 */
const unfollowUser = async (req, res, next) => {
  try {
    await query(
      'DELETE FROM follows WHERE follower_id = $1 AND following_id = $2',
      [req.user.id, req.params.id]
    );
    res.json({ message: 'Unfollowed.' });
  } catch (err) {
    next(err);
  }
};

module.exports = { getProfile, upsertProfile, followUser, unfollowUser };
