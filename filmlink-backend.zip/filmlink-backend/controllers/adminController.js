const { query } = require('../config/db');

/**
 * GET /api/admin/applications?status=pending
 */
const listApplications = async (req, res, next) => {
  try {
    const { status = 'pending', page = 1, limit = 50 } = req.query;
    const { rows } = await query(
      `SELECT ca.*, u.email
       FROM creator_applications ca
       JOIN users u ON u.id = ca.user_id
       WHERE ca.status = $1
       ORDER BY ca.created_at ASC
       LIMIT $2 OFFSET $3`,
      [status, limit, (page - 1) * limit]
    );
    res.json({ applications: rows });
  } catch (err) {
    next(err);
  }
};

/**
 * PATCH /api/admin/applications/:id
 * Body: { status: 'approved'|'rejected'|'info_requested', admin_notes? }
 */
const reviewApplication = async (req, res, next) => {
  try {
    const { status, admin_notes } = req.body;
    const validStatuses = ['approved', 'rejected', 'info_requested'];
    if (!validStatuses.includes(status)) {
      return res.status(422).json({ error: `status must be one of: ${validStatuses.join(', ')}` });
    }

    const { rows: [application] } = await query(
      `UPDATE creator_applications
       SET status = $1, admin_notes = $2, reviewed_by = $3, reviewed_at = NOW(), updated_at = NOW()
       WHERE id = $4
       RETURNING *`,
      [status, admin_notes, req.user.id, req.params.id]
    );
    if (!application) return res.status(404).json({ error: 'Application not found.' });

    // Promote user to creative on approval
    if (status === 'approved') {
      await query(
        `UPDATE users SET user_type = 'creative' WHERE id = $1`,
        [application.user_id]
      );
    }

    res.json({ application });
  } catch (err) {
    next(err);
  }
};

/**
 * PATCH /api/admin/users/:id/deactivate
 */
const deactivateUser = async (req, res, next) => {
  try {
    const { rows: [user] } = await query(
      `UPDATE users SET is_active = false WHERE id = $1 RETURNING id, email, user_type`,
      [req.params.id]
    );
    if (!user) return res.status(404).json({ error: 'User not found.' });
    res.json({ user, message: 'User deactivated.' });
  } catch (err) {
    next(err);
  }
};

module.exports = { listApplications, reviewApplication, deactivateUser };
