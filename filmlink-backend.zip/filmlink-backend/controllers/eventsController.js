const { query } = require('../config/db');

/** GET /api/events */
const listEvents = async (req, res, next) => {
  try {
    const { rows } = await query(
      `SELECT * FROM events WHERE starts_at >= NOW() ORDER BY starts_at ASC LIMIT 50`
    );
    res.json({ events: rows });
  } catch (err) { next(err); }
};

/** GET /api/events/:id */
const getEvent = async (req, res, next) => {
  try {
    const { rows: [event] } = await query('SELECT * FROM events WHERE id = $1', [req.params.id]);
    if (!event) return res.status(404).json({ error: 'Event not found.' });
    res.json({ event });
  } catch (err) { next(err); }
};

/** POST /api/events/:id/rsvp  (authenticated) */
const rsvp = async (req, res, next) => {
  try {
    await query(
      `INSERT INTO event_rsvps (event_id, user_id) VALUES ($1,$2) ON CONFLICT DO NOTHING`,
      [req.params.id, req.user.id]
    );
    res.json({ message: 'RSVP confirmed.' });
  } catch (err) { next(err); }
};

module.exports = { listEvents, getEvent, rsvp };
