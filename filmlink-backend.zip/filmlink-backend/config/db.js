const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
});

pool.on('error', (err) => {
  console.error('Unexpected error on idle PostgreSQL client:', err);
  process.exit(-1);
});

/**
 * Run a parameterized query.
 * Usage: const { rows } = await query('SELECT * FROM users WHERE id = $1', [id])
 */
const query = (text, params) => pool.query(text, params);

/**
 * Acquire a client for transactions.
 * Usage:
 *   const client = await getClient()
 *   try {
 *     await client.query('BEGIN')
 *     ...
 *     await client.query('COMMIT')
 *   } catch (e) {
 *     await client.query('ROLLBACK')
 *   } finally {
 *     client.release()
 *   }
 */
const getClient = () => pool.connect();

module.exports = { query, getClient, pool };
