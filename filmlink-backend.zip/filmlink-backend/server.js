require('dotenv').config();

const express = require('express');
const cors    = require('cors');
const helmet  = require('helmet');
const morgan  = require('morgan');

const { errorHandler, notFound } = require('./middleware/errorHandler');

// ── Route modules ─────────────────────────────────────────────────────────────
const authRoutes         = require('./routes/auth');
const usersRoutes        = require('./routes/users');
const projectsRoutes     = require('./routes/projects');
const applicationsRoutes = require('./routes/applications');
const eventsRoutes       = require('./routes/events');
const articlesRoutes     = require('./routes/articles');
const classesRoutes      = require('./routes/classes');
const adminRoutes        = require('./routes/admin');

const app = express();

// ── Security & parsing ────────────────────────────────────────────────────────
app.use(helmet());
app.use(cors({
  origin: (process.env.ALLOWED_ORIGINS || '').split(',').map(o => o.trim()),
  credentials: true,
}));
app.use(express.json({ limit: '10mb' }));
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));

// ── Health check ──────────────────────────────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// ── API routes ────────────────────────────────────────────────────────────────
app.use('/api/auth',         authRoutes);
app.use('/api/users',        usersRoutes);
app.use('/api/projects',     projectsRoutes);
app.use('/api/applications', applicationsRoutes);
app.use('/api/events',       eventsRoutes);
app.use('/api/articles',     articlesRoutes);
app.use('/api/classes',      classesRoutes);
app.use('/api/admin',        adminRoutes);

// ── Error handling (must be last) ─────────────────────────────────────────────
app.use(notFound);
app.use(errorHandler);

// ── Start server ──────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`\n🎬  FilmLink API running on port ${PORT} [${process.env.NODE_ENV || 'development'}]`);
  console.log(`    Health: http://localhost:${PORT}/health\n`);
});

module.exports = app;
