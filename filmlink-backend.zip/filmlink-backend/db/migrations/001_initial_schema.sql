-- FilmLink — Initial Schema Migration
-- Run once against your Postgres instance:
--   psql $DATABASE_URL -f db/migrations/001_initial_schema.sql

-- ─── Extensions ───────────────────────────────────────────────────────────────
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "citext";   -- case-insensitive text (emails)

-- ─── Enums ────────────────────────────────────────────────────────────────────
CREATE TYPE user_type AS ENUM ('creative', 'fan', 'admin');
CREATE TYPE application_status AS ENUM ('pending', 'approved', 'rejected', 'info_requested');
CREATE TYPE project_status AS ENUM ('open', 'casting', 'in_production', 'completed', 'closed');
CREATE TYPE compensation_type AS ENUM ('paid', 'unpaid', 'deferred', 'copy_credit');

-- ─── Users ────────────────────────────────────────────────────────────────────
CREATE TABLE users (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email         CITEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  user_type     user_type NOT NULL DEFAULT 'fan',
  is_active     BOOLEAN NOT NULL DEFAULT true,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── Creative Profiles ────────────────────────────────────────────────────────
CREATE TABLE creative_profiles (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  display_name    TEXT NOT NULL,
  profession      TEXT,                  -- Actor, Director, DP, etc.
  bio             TEXT,
  location        TEXT,
  headshot_url    TEXT,
  reel_url        TEXT,
  resume_url      TEXT,
  skills          TEXT[],
  social_links    JSONB DEFAULT '{}',   -- { instagram: "...", imdb: "..." }
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (user_id)
);

-- ─── Creator Applications (approval queue) ───────────────────────────────────
CREATE TABLE creator_applications (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status          application_status NOT NULL DEFAULT 'pending',
  profession      TEXT NOT NULL,
  bio             TEXT NOT NULL,
  headshot_url    TEXT,
  reel_url        TEXT,
  resume_url      TEXT,
  admin_notes     TEXT,
  reviewed_by     UUID REFERENCES users(id),
  reviewed_at     TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── Projects ─────────────────────────────────────────────────────────────────
CREATE TABLE projects (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  owner_id        UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title           TEXT NOT NULL,
  description     TEXT,
  genre           TEXT,
  project_type    TEXT,                  -- short film, web series, music video…
  status          project_status NOT NULL DEFAULT 'open',
  location        TEXT,
  shoot_start     DATE,
  shoot_end       DATE,
  is_featured     BOOLEAN NOT NULL DEFAULT false,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── Project Roles ────────────────────────────────────────────────────────────
CREATE TABLE project_roles (
  id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  project_id        UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  role_name         TEXT NOT NULL,
  role_type         TEXT,               -- Actor, DP, Editor, etc.
  description       TEXT,
  compensation      compensation_type NOT NULL DEFAULT 'unpaid',
  compensation_note TEXT,
  audition_info     TEXT,
  is_filled         BOOLEAN NOT NULL DEFAULT false,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── Role Applications ────────────────────────────────────────────────────────
CREATE TABLE role_applications (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  role_id         UUID NOT NULL REFERENCES project_roles(id) ON DELETE CASCADE,
  applicant_id    UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  cover_note      TEXT,
  audition_url    TEXT,
  status          application_status NOT NULL DEFAULT 'pending',
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (role_id, applicant_id)
);

-- ─── Follows ──────────────────────────────────────────────────────────────────
CREATE TABLE follows (
  follower_id   UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  following_id  UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (follower_id, following_id),
  CHECK (follower_id <> following_id)
);

-- ─── Events ───────────────────────────────────────────────────────────────────
CREATE TABLE events (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title         TEXT NOT NULL,
  description   TEXT,
  event_type    TEXT,                   -- mixer, screening, panel, workshop
  location      TEXT,
  is_online     BOOLEAN NOT NULL DEFAULT false,
  starts_at     TIMESTAMPTZ NOT NULL,
  ends_at       TIMESTAMPTZ,
  ticket_price  NUMERIC(10,2),
  capacity      INT,
  created_by    UUID REFERENCES users(id),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── Event RSVPs ──────────────────────────────────────────────────────────────
CREATE TABLE event_rsvps (
  event_id    UUID NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  checked_in  BOOLEAN NOT NULL DEFAULT false,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (event_id, user_id)
);

-- ─── Acting Classes ───────────────────────────────────────────────────────────
CREATE TABLE acting_classes (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name          TEXT NOT NULL,
  provider      TEXT NOT NULL,
  description   TEXT,
  location      TEXT,
  is_online     BOOLEAN NOT NULL DEFAULT false,
  price         NUMERIC(10,2),
  schedule_info TEXT,
  website_url   TEXT,
  is_active     BOOLEAN NOT NULL DEFAULT true,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── Class Reviews ────────────────────────────────────────────────────────────
CREATE TABLE class_reviews (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  class_id    UUID NOT NULL REFERENCES acting_classes(id) ON DELETE CASCADE,
  reviewer_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  rating      SMALLINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  review_text TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (class_id, reviewer_id)
);

-- ─── Articles ─────────────────────────────────────────────────────────────────
CREATE TABLE articles (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  author_id     UUID REFERENCES users(id),
  title         TEXT NOT NULL,
  slug          TEXT UNIQUE NOT NULL,
  body          TEXT NOT NULL,
  cover_url     TEXT,
  category      TEXT,
  is_published  BOOLEAN NOT NULL DEFAULT false,
  is_sponsored  BOOLEAN NOT NULL DEFAULT false,
  published_at  TIMESTAMPTZ,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── Indexes ──────────────────────────────────────────────────────────────────
CREATE INDEX idx_creative_profiles_user_id ON creative_profiles(user_id);
CREATE INDEX idx_projects_owner_id ON projects(owner_id);
CREATE INDEX idx_projects_status ON projects(status);
CREATE INDEX idx_project_roles_project_id ON project_roles(project_id);
CREATE INDEX idx_role_applications_role_id ON role_applications(role_id);
CREATE INDEX idx_role_applications_applicant_id ON role_applications(applicant_id);
CREATE INDEX idx_creator_applications_status ON creator_applications(status);
CREATE INDEX idx_articles_slug ON articles(slug);
CREATE INDEX idx_articles_published ON articles(is_published, published_at DESC);
CREATE INDEX idx_events_starts_at ON events(starts_at);
